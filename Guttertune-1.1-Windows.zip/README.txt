GUTTERTUNE 1.1 - underground vocal tuner + effects
For FL Studio 2024 or newer, 64-bit Windows (CLAP format).

INSTALL
 1. Close FL Studio.
 2. If Windows blocked the download: right-click the zip > Properties > tick "Unblock" > OK,
    then unzip it.
 3. Copy Guttertune.clap into:   C:\Program Files\Common Files\CLAP
 4. Open FL Studio > Options > Manage plugins > Find installed plugins.
 5. Add Guttertune to the FIRST effect slot of your vocal's mixer track.

QUICK START
 1. Click your beat's key on the piano, then pick the scale with the arrows.
    Pink = key, light = notes in the scale, blue = note being sung.
 2. Retune Speed all the way down (HARD) for the robotic snap. Turn up for natural.
 3. Hit a vibe button, then tweak to taste.

CONTROLS
 PITCH     shift the voice -12 to +12 semitones
 FORMANT   darker/bigger (left) or thinner/smaller (right)
 DOUBLE    wide stereo double
 CRUSH     lo-fi bit and sample-rate reduction
 DIRT      saturation
 PHONE     telephone filter
 ECHO      ping-pong dotted-eighth delay synced to your tempo
 REVERB    room tail
 MIX       dry/wet (below 100% blends in the untuned voice)
 OUTPUT    final volume

 Vibes: RAGE, PLUGG, DEMON, ALIEN, PAYPHONE. They change speed, pitch, formant and effects,
 and leave Key, Scale, Mix and Output alone.

 Drag knobs up/down. Shift-drag = fine. Mouse wheel works. Double-click or Ctrl-click = reset.

AUTOMATION
 Right-click a knob. If FL Studio supplies its menu there, pick Create automation clip.
 If you see the plugin's small backup menu instead, close it, then use
 Tools menu > Last tweaked > Create automation clip (your knob is already selected).

TIPS
 * Use it on ONE voice at a time, as dry as possible (no beat bleed, reverb or stacked takes).
 * Works on pitches from about 75 to 900 Hz.
 * Latency is about 40 ms and is reported to FL Studio. That is noticeable if you monitor
   yourself through it while recording: record dry (or use direct monitoring), then tune.
 * Echo and Reverb tails: turn monitors down while experimenting with heavy settings.
